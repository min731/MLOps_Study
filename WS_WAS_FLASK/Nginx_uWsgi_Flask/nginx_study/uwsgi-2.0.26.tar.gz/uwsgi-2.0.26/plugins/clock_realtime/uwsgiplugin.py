NAME='clock_realtime'

CFLAGS = []
LDFLAGS = []
LIBS = ['-lrt']
GCC_LIST = ['clock_realtime']
