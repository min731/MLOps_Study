
NAME='rawrouter'
CFLAGS = []
LDFLAGS = []
LIBS = []

REQUIRES = ['corerouter']

GCC_LIST = ['rawrouter']
